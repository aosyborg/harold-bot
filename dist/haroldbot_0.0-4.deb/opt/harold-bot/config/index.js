module.exports = {
    token: process.env.SLACK_TOKEN || 'xoxb-3766806459-mWtiVLi0QwdO0rpdVvQqGH4n',
    autoReconnect: process.env.SLACK_AUTORECONNECT || true,
    autoMark: process.env.SLACK_AUTOMARK || true,
};
