#!/usr/bin/env bash

export SLACK_TOKEN=''
export SLACK_AUTORECONNECT=true
export SLACK_AUTOMARK=true
