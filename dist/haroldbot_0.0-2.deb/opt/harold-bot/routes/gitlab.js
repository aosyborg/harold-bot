var express = require('express'),
    router = express.Router();

router.get('/gitlab/merge-request', function (request, response, next) {
    var body = require('./gitlab-merge-request'),
        properties = {
            namespace: body.object_attributes.target.namespace,
            name: body.object_attributes.target.name,
            action: body.object_attributes.action,
            title: body.object_attributes.title,
            url: body.object_attributes.url,
            user: body.user.name
        };

    var slack = request.slack,
        channel = slack.getChannelByName('general');

    channel.postMessage({
        username: 'harold-bot',
        icon_url: 'https://s3-us-west-2.amazonaws.com/slack-files2/avatars/2015-02-18/3766806521_0b6aba5ca200538b9496_48.jpg',
        text: '[' + properties.namespace + '/' + properties.name + '] ',
        attachments: [{
            pretext: 'Merge request ' + properties.action + ': ',
            title: properties.title,
            title_link: properties.url,
            text: 'by ' + properties.user,
            color: '#7CD197'
        }]
    });

    response.json('Ok');
});

module.exports = router;
