module.exports = {
    // Harold-bot slack settings
    token: 'xoxb-3766806459-mWtiVLi0QwdO0rpdVvQqGH4n',
    autoReconnect: true,
    autoMark: true,
};
